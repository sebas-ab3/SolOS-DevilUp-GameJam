// Assets/Scripts/Core/GameState.cs
namespace Game.Core
{
    public enum GameState
    {
        Boot,
        Freeplay,
        Intermission,
        Match,
        Tutorial,
        CampaignComplete
    }
}